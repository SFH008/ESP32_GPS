# ESP32-S3 NMEA 2000 GPS Node

High-quality GPS position source for NMEA 2000 backbone.  
Replaces/supplements internal GPS in Raymarine Axiom MFDs.

## Hardware

| Component | Part |
|---|---|
| MCU | M5Stack AtomS3-Lite (ESP32-S3FN8) |
| CAN interface | M5Stack Atomic CAN Base (CA-IS3050G, galvanically isolated) |
| GPS module | SparkFun NEO-M9N SMA Breakout |
| Buck converter | Pololu D24V10F5 (12V → 5V) |
| Antenna | Active GNSS antenna, SMA, magnetic/deck mount |

## Wiring

```
N2K bus 12V ──→ Pololu D24V10F5 ──→ 5V USB-C ──→ AtomS3-Lite
                                                        │
                                          Atomic CAN Base (bottom)
                                          ├── CAN H ──→ N2K backbone
                                          └── CAN L ──→ N2K backbone

AtomS3-Lite HY2.0-4P (side port):
  Black (GND)   ──→ NEO-M9N GND
  Red   (5V)    ──→ (do not connect — M9N runs on 3.3V)
  Yellow (G2)   ──→ NEO-M9N TX
  White  (G1)   ──→ NEO-M9N RX

AtomS3-Lite bottom header 3.3V ──→ NEO-M9N VCC

NEO-M9N SMA ──→ coax ──→ active deck antenna
```

> **Note:** The Atomic CAN Base has no built-in termination resistor.
> Your N2K backbone should already be terminated at both ends (120Ω).
> This node is a drop device — no resistor required.

## PGNs Transmitted

| PGN | Description | Rate |
|---|---|---|
| 129025 | Position, Rapid Update | 10 Hz |
| 129026 | COG & SOG, Rapid Update | 10 Hz |
| 129029 | GNSS Position Data | 1 Hz |
| 126992 | System Time | 1 Hz |

## First Flash (USB)

The ESP32-S3 requires download mode for first flash over USB-CDC:

1. Hold the AtomS3-Lite reset button ~2 seconds until the internal green LED lights, then release
2. In `platformio.ini`, comment out `upload_protocol = espota` and `upload_port`
3. Add: `upload_protocol = esptool`
4. Run: `pio run -t upload`
5. After first flash, restore OTA upload settings for subsequent updates

## OTA Updates

After first flash, updates are wireless:

```bash
pio run -t upload
# Uploads to esp32s3-gps.local:3232
```

## Verifying on the N2K Bus

From your Pi running Venus OS with PiCAN-M:

```bash
# Confirm PGNs are appearing on the bus
candump can0 | grep -E "1F805|1F80E|1F10D|1EF00"
#              129029   129026   129025   126992

# Or use canboat to decode:
analyzer -json < <(candump -L /dev/null can0)
```

In Raymarine Axiom:
- Settings → Network → Data Sources → Position Source
- Select the new device (will appear as "ESP32S3-GPS-NODE" or similar)

## LED Status

| Colour | Meaning |
|---|---|
| Blue | Booting |
| Red | No GPS fix |
| Green | GPS fix valid, transmitting |
| Amber | OTA update in progress |

## GPS Configuration

The NEO-M9N is configured on first boot:
- **10 Hz** measurement rate
- **UBX binary protocol** (NMEA disabled for reliability)
- **SEA dynamic model** (Kalman filter tuned for marine use)
- **All four constellations**: GPS + GLONASS + Galileo + BeiDou
- Config saved to module flash (survives power cycle)

## Project Structure

```
src/
  Config.h          Pin definitions, N2K identity, timing constants
  secrets.h         WiFi credentials (not committed to git)
  GPSParser.h/.cpp  NEO-M9N driver via SparkFun u-blox GNSS v3
  N2KHandler.h/.cpp PGN 129025/129026/129029/126992 transmit
  main.cpp          Setup, loop, OTA, LED
platformio.ini      Build config targeting AtomS3-Lite
```
