#include <Arduino.h>

// ── NMEA2000 via TWAI ─────────────────────────────────────────────────────────
// Do NOT use NMEA2000_CAN.h — on ESP32 it selects the MCP2515/SPI driver
// (NMEA2000_esp32.h), not the built-in TWAI peripheral.
// Instantiate the TWAI driver directly with the Atomic CAN Base pins.
#include <NMEA2000_esp32_twai.h>
tNMEA2000_esp32_twai NMEA2000(GPIO_NUM_5, GPIO_NUM_6);  // G5=TX, G6=RX

#include <N2kMessages.h>
#include <WiFi.h>
#include <ArduinoOTA.h>
#include <Adafruit_NeoPixel.h>

#include "Config.h"
#include "GPSParser.h"
#include "N2KHandler.h"
#include "secrets.h"

// ═══════════════════════════════════════════════════════════════════════════
//  Globals
// ═══════════════════════════════════════════════════════════════════════════

GPSParser           gpsParser;
N2KHandler          n2kHandler;
Adafruit_NeoPixel   statusLed(1, LED_PIN, NEO_GRB + NEO_KHZ800);

// PGNs this node transmits — declared for N2K address claiming
const unsigned long TX_PGN_LIST[] PROGMEM = {
    126992L,    // System Time
    129025L,    // Position, Rapid Update
    129026L,    // COG & SOG, Rapid Update
    129029L,    // GNSS Position Data
    0
};

// ═══════════════════════════════════════════════════════════════════════════
//  LED
// ═══════════════════════════════════════════════════════════════════════════

enum LedState { LED_BOOTING, LED_NO_FIX, LED_FIX, LED_OTA };

void setLed(LedState state) {
    uint32_t c;
    switch (state) {
        case LED_BOOTING: c = statusLed.Color(0, 0, LED_BRIGHTNESS);                  break; // blue
        case LED_NO_FIX:  c = statusLed.Color(LED_BRIGHTNESS, 0, 0);                  break; // red
        case LED_FIX:     c = statusLed.Color(0, LED_BRIGHTNESS, 0);                  break; // green
        case LED_OTA:     c = statusLed.Color(LED_BRIGHTNESS, LED_BRIGHTNESS/2, 0);   break; // amber
        default:          c = 0; break;
    }
    statusLed.setPixelColor(0, c);
    statusLed.show();
}

// ═══════════════════════════════════════════════════════════════════════════
//  WiFi + OTA
// ═══════════════════════════════════════════════════════════════════════════

void setupWiFiAndOTA() {
    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    Serial.printf("[WiFi] Connecting to %s", WIFI_SSID);

    uint8_t attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 20) {
        delay(500);
        Serial.print(".");
        attempts++;
    }

    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("\n[WiFi] Failed — OTA unavailable. Continuing.");
        return;
    }
    Serial.printf("\n[WiFi] Connected: %s\n", WiFi.localIP().toString().c_str());

    ArduinoOTA.setHostname(OTA_HOSTNAME);
    ArduinoOTA.setPort(OTA_PORT);

    ArduinoOTA.onStart([]() {
        setLed(LED_OTA);
        Serial.println("[OTA] Starting update...");
    });
    ArduinoOTA.onEnd([]() {
        Serial.println("\n[OTA] Complete. Rebooting.");
    });
    ArduinoOTA.onError([](ota_error_t e) {
        Serial.printf("[OTA] Error[%u]\n", e);
    });
    ArduinoOTA.onProgress([](unsigned int p, unsigned int t) {
        Serial.printf("[OTA] %u%%\r", p * 100 / t);
    });

    ArduinoOTA.begin();
    Serial.printf("[OTA] Ready — hostname: %s, port: %d\n", OTA_HOSTNAME, OTA_PORT);
}

// ═══════════════════════════════════════════════════════════════════════════
//  NMEA 2000
// ═══════════════════════════════════════════════════════════════════════════

void setupNMEA2000() {
    NMEA2000.SetProductInformation(
        N2K_DEVICE_SERIAL_CODE,
        100,                            // Product code (arbitrary for DIY)
        N2K_DEVICE_MODEL_ID,
        N2K_DEVICE_SW_VERSION,
        N2K_DEVICE_MODEL_VERSION
    );
    NMEA2000.SetDeviceInformation(
        N2K_UNIQUE_NUMBER,
        N2K_DEVICE_FUNCTION,            // 145 = GPS
        N2K_DEVICE_CLASS,               // 60  = Navigation
        N2K_MANUFACTURER_CODE
    );

    // N2km_NodeOnly: this node only transmits; does not forward to Serial
    NMEA2000.SetMode(tNMEA2000::N2km_NodeOnly, 25);
    NMEA2000.ExtendTransmitMessages(TX_PGN_LIST);
    NMEA2000.EnableForward(false);
    NMEA2000.Open();

    Serial.println("[N2K] Bus open — address claiming started.");
}

// ═══════════════════════════════════════════════════════════════════════════
//  setup()
// ═══════════════════════════════════════════════════════════════════════════

void setup() {
    Serial.begin(115200);
    delay(200);
    Serial.println("\n══════════════════════════════════════");
    Serial.println(" ESP32-S3 NMEA2000 GPS Node  v1.0.0");
    Serial.println("══════════════════════════════════════");

    statusLed.begin();
    statusLed.setBrightness(LED_BRIGHTNESS);
    setLed(LED_BOOTING);

    setupWiFiAndOTA();
    setupNMEA2000();
    n2kHandler.begin(&NMEA2000);

    if (!gpsParser.begin()) {
        Serial.println("\n[BOOT] *** GPS INIT FAILED ***");
        Serial.println("[BOOT] Check NEO-M9N wiring: G1→RX, G2→TX, 3.3V→VCC");
        // Blink red and halt — don't transmit invalid data onto the bus
        while (true) {
            setLed(LED_NO_FIX);
            delay(500);
            statusLed.setPixelColor(0, 0);
            statusLed.show();
            delay(500);
        }
    }

    Serial.println("[BOOT] GPS ready. Waiting for fix...");
    setLed(LED_NO_FIX);
}

// ═══════════════════════════════════════════════════════════════════════════
//  loop()
// ═══════════════════════════════════════════════════════════════════════════

void loop() {
    // Handle OTA updates — must be called every loop iteration
    ArduinoOTA.handle();

    // Poll GPS — non-blocking; returns true when a new NAV-PVT packet arrived
    bool newData = gpsParser.poll();
    const GpsData& gps = gpsParser.data();

    if (newData) {
        setLed(gps.positionValid ? LED_FIX : LED_NO_FIX);

#if CORE_DEBUG_LEVEL > 0
        Serial.printf("[GPS] Fix:%d Sats:%02d  %11.6f %11.6f  "
                      "Alt:%6.1fm  COG:%6.1f°  SOG:%5.2fkn  "
                      "HDOP:%.1f  %02d:%02d:%02dZ\n",
            gps.fixType, gps.satellites,
            gps.latitude, gps.longitude,
            gps.altitude,
            gps.cogTrue,
            gps.sogMs * 1.94384f,   // m/s → knots for display
            gps.hdop,
            gps.hour, gps.minute, gps.second);
#endif
    }

    // Always call update — it manages PGN timing internally AND calls
    // ParseMessages() which services address claiming on every iteration.
    n2kHandler.update(gps);
}
