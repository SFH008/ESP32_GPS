#pragma once

// ── WiFi credentials for OTA ──────────────────────────────────────────────
// DO NOT commit this file. It is listed in .gitignore.
#define WIFI_SSID       "your_wifi_ssid"
#define WIFI_PASSWORD   "your_wifi_password"
