#pragma once

// ═══════════════════════════════════════════════════════════════════════════
//  Config.h — All pins, constants, and N2K identity in one place
//
//  Hardware: AtomS3-Lite + Atomic CAN Base + SparkFun NEO-M9N SMA
// ═══════════════════════════════════════════════════════════════════════════

// ── CAN / TWAI ───────────────────────────────────────────────────────────────
// Atomic CAN Base mates to AtomS3-Lite via bottom GPIO header.
// G5=CAN TX, G6=CAN RX — fixed by the module hardware.
// The tNMEA2000_esp32_twai object in main.cpp is instantiated with these pins.
// No #defines needed here — they are constructor arguments, not compile-time macros.

// ── GPS UART ─────────────────────────────────────────────────────────────────
// HY2.0-4P side port (Port.CUSTOM):
//   Black=GND  Red=5V(unused)  Yellow=G2  White=G1
// Wire: G1 → NEO-M9N RX,  G2 → NEO-M9N TX
// Power: 3.3V from AtomS3-Lite bottom header → NEO-M9N VCC
#define GPS_UART_PORT       1               // UART1
#define GPS_TX_PIN          1               // G1 → NEO-M9N RX
#define GPS_RX_PIN          2               // G2 → NEO-M9N TX
#define GPS_BAUD_INITIAL    38400           // NEO-M9N factory default
#define GPS_BAUD_TARGET     115200          // Reconfigured on first boot

// ── Status LED ───────────────────────────────────────────────────────────────
// AtomS3-Lite onboard WS2812C-2020 RGB LED
#define LED_PIN             38
#define LED_BRIGHTNESS      20              // 0–255; keep low, very bright chip

// ── OTA / WiFi ───────────────────────────────────────────────────────────────
#define OTA_HOSTNAME        "esp32s3-gps"
#define OTA_PORT            3232

// ── NMEA 2000 Device Identity ─────────────────────────────────────────────────
// Unique Number must be unique across all your N2K devices (0–2097151).
// Change this if you have multiple nodes.
#define N2K_UNIQUE_NUMBER           2001
#define N2K_MANUFACTURER_CODE       2046    // 0x7FE = DIY/unknown
#define N2K_DEVICE_FUNCTION         145     // GPS — N2K device function table
#define N2K_DEVICE_CLASS            60      // Navigation
#define N2K_INDUSTRY_GROUP          4       // Marine
#define N2K_DEVICE_INSTANCE         0
#define N2K_SYSTEM_INSTANCE         0
#define N2K_DEVICE_MODEL_ID         "ESP32S3-GPS-NODE"
#define N2K_DEVICE_SW_VERSION       "1.0.0"
#define N2K_DEVICE_MODEL_VERSION    "AtomS3+M9N"
#define N2K_DEVICE_SERIAL_CODE      "00000001"

// ── PGN Transmit Intervals ────────────────────────────────────────────────────
#define INTERVAL_RAPID_MS           100     // 10 Hz — PGN 129025 + 129026
#define INTERVAL_FULL_FIX_MS        1000    //  1 Hz — PGN 129029 + 126992

// ── GPS Fix Threshold ─────────────────────────────────────────────────────────
#define MIN_SATELLITES_FOR_VALID    4
